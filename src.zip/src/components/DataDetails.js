import React from "react";
import styled from "styled-components";

const StyledArticle = styled.div`
  h1 {
    font-weight: 700;
    font-size: 36px;
    color: #000000;
    margin: 0;
  }
  h4 {
    font-weight: 700;
    font-size: 20px;
    color: #000000;
    margin: 0.5rem 0 4rem 0;
  }
  p {
    font-weight: 300;
    font-size: 18px;
    color: #4a4a4a;
  }
`;

const DataDetails = ({  places = [] }) => {
  return (
    <StyledArticle>
      
      {places.map(place => (
        <p key={place.name}>
		<a href={"pagedetails/" +place.id} onClick={place.id}> {place.name} <br /><img src={place.cover} alt={place.name} width="170px" /></a></p>
      ))}
    </StyledArticle>
  );
};

export default DataDetails;