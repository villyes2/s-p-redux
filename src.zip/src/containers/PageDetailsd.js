import React, { Component } from "react";
import { connect } from "react-redux";
import axios from 'axios';
//import styled from "styled-components";
//import PageDetails from "../components/PageDetails";
//import { fetchArticleDetails } from "../actions/details";



class PageDetailsd extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
	   
      placesw: []
    };
  }

     
  componentDidMount() {
	  
	  const disp = this.props.location.pathname;
const tid = disp.replace('/pagedetails/', '');
console.log(tid);
	   const proxyurl = "https://cors-anywhere.herokuapp.com/";
    axios.get(proxyurl +"https://roadtrippers.herokuapp.com/api/v1/place/"+tid, {   method:'GET',
            mode: 'cors',
            headers:{
                'Access-Control-Allow-Origin':'*'
            },
        })
      .then(res => {
        const placesw = res.data;
        this.setState({ placesw });
      })
  }

  render() {
    return (
	 <div>  
     <div class="row">
<div class="col-xs-12">
      <ul>
        { this.state.placesw.map(plac => 
		<div class="col-md-6">	  
	  <div class="info-box">
		<li>{plac.name}<br /><img src={plac.cover} width="350px" /></li> 
		</div></div>
		)}
      </ul></div></div>
		
          </div>
    )
  }
}

export default PageDetailsd;